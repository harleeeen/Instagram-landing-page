import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import "./App.css";

const images = [
  {
    src: "https://images.unsplash.com/photo-1503023345310-bd7c1de61c7d?auto=format&fit=crop&w=800&q=80",
    alt: "Beach Sunset Post",
  },
  {
    src: "https://images.unsplash.com/photo-1494526585095-c41746248156?auto=format&fit=crop&w=800&q=80",
    alt: "Urban Life Post",
  },
  {
    src: "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?auto=format&fit=crop&w=800&q=80",
    alt: "Happy Friends Post",
  },
];

export default function App() {
  const [darkMode, setDarkMode] = useState(() => localStorage.getItem("theme") === "dark");
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", darkMode);
    localStorage.setItem("theme", darkMode ? "dark" : "light");
  }, [darkMode]);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % images.length);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-white dark:bg-gray-900 text-gray-800 dark:text-white min-h-screen transition-colors duration-500">
      <header className="sticky top-0 bg-white dark:bg-gray-900 shadow-md z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <h1 className="text-3xl font-bold text-pink-500 dark:text-pink-400">Instagram</h1>
          <div className="flex items-center space-x-4">
            <button
              onClick={() => setDarkMode(!darkMode)}
              className="text-2xl focus:outline-none hover:scale-110 transition-transform"
              aria-label="Toggle Dark Mode"
            >
              {darkMode ? "☀️" : "🌙"}
            </button>
            <a href="/login" className="text-blue-600 dark:text-blue-400 hover:underline">
              Log In
            </a>
            <a
              href="/signup"
              className="bg-blue-600 text-white px-4 py-2 rounded-full hover:bg-blue-700 transition"
            >
              Sign Up
            </a>
          </div>
        </div>
      </header>

      <section className="flex flex-col-reverse lg:flex-row items-center justify-between max-w-7xl mx-auto px-6 py-20 gap-12">
        <motion.div
          className="lg:w-1/2"
          initial={{ opacity: 0, x: -60 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-5xl font-extrabold mb-6">Share Life’s Moments</h2>
          <p className="text-lg mb-6 text-gray-600 dark:text-gray-300">
            Capture and share the world's moments with friends, from your everyday experiences to the spectacular.
          </p>
          <div className="flex gap-4">
            <a
              href="https://play.google.com/store/apps/details?id=com.instagram.android"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-black text-white px-5 py-3 rounded-lg hover:bg-gray-800"
            >
              Get it on Android
            </a>
            <a
              href="https://apps.apple.com/app/instagram/id389801252"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-black text-white px-5 py-3 rounded-lg hover:bg-gray-800"
            >
              Download on iOS
            </a>
          </div>
        </motion.div>

        <motion.div
          className="lg:w-1/2 flex justify-center"
          initial={{ opacity: 0, x: 60 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
        >
          <img
            src="https://upload.wikimedia.org/wikipedia/commons/a/a5/Instagram_icon.png"
            alt="Instagram Icon"
            className="w-72 lg:w-96 drop-shadow-lg rounded-2xl"
          />
        </motion.div>
      </section>

      <section className="bg-gray-100 dark:bg-gray-800 py-20">
        <div className="max-w-4xl mx-auto px-6">
          <h3 className="text-3xl font-semibold text-center mb-10">Trending Posts</h3>
          <div className="relative h-64 md:h-96 rounded-xl overflow-hidden">
            {images.map((img, i) => (
              <motion.img
                key={i}
                src={img.src}
                alt={img.alt}
                className={`absolute w-full h-full object-cover transition-opacity duration-700 ${
                  i === currentSlide ? "opacity-100" : "opacity-0"
                }`}
              />
            ))}
            <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-3">
              {images.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentSlide(i)}
                  className={`w-3 h-3 rounded-full ${
                    i === currentSlide ? "bg-pink-500" : "bg-pink-300"
                  } opacity-80 hover:opacity-100`}
                ></button>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white dark:bg-gray-900">
        <div className="max-w-6xl mx-auto px-6 grid md:grid-cols-3 gap-10">
          {[
            {
              icon: "📸",
              title: "Capture Moments",
              text: "Snap and share high-quality images and videos instantly.",
              color: "text-pink-500 dark:text-pink-400",
            },
            {
              icon: "💬",
              title: "Connect Instantly",
              text: "Chat with friends and react to their stories in real time.",
              color: "text-blue-500 dark:text-blue-400",
            },
            {
              icon: "🌎",
              title: "Discover More",
              text: "Explore new content tailored to your interests and network.",
              color: "text-purple-500 dark:text-purple-400",
            },
          ].map((f, i) => (
            <motion.div
              key={i}
              className="bg-gray-50 dark:bg-gray-700 p-6 rounded-xl shadow hover:shadow-md transition"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: i * 0.2 }}
            >
              <h4 className={`text-2xl mb-2 ${f.color}`}>{f.icon} {f.title}</h4>
              <p className="text-gray-600 dark:text-gray-300">{f.text}</p>
            </motion.div>
          ))}
        </div>
      </section>

      <footer className="bg-gray-100 dark:bg-gray-900 py-6 text-center text-gray-500 text-sm">
        &copy; 2025 Instagram Clone. Created for educational use only.
      </footer>
    </div>
  );
}
